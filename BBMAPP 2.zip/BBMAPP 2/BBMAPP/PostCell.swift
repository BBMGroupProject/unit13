//
//  PostCell.swift
//  BBMAPP
//
//  Created by user189845 on 4/18/21.
//

import UIKit

class PostCell: UITableViewCell {
    
    @IBOutlet weak var businessLogo: UIImageView!
    @IBOutlet weak var nameLabel: UITextField!
    @IBOutlet weak var categoryLabel: UITextField!
    @IBOutlet weak var locationLabel: UITextField!
    @IBOutlet weak var websiteLabel: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var tableView: UITableView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
